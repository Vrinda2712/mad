package com.example.math

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
