package com.example.user_authentication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
